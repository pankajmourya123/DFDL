import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;

public class TEST_MbElement_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try {
			
			MbMessage outMessage=new MbMessage();
			  // Root element
           int type_name=MbElement.TYPE_NAME;
           
            MbElement outRoot=outMessage.getRootElement();
			MbElement xmlnsc=outRoot.createElementAsLastChild("XMLNSC");
			 // Parent node
			MbElement Root=xmlnsc.createElementAsFirstChild(MbElement.TYPE_NAME, "Root", null);
            MbElement fieldsParent = Root.createElementAsFirstChild(MbElement.TYPE_NAME, "Fields", null);
            MbElement SecondParent = Root.createElementAsLastChild(MbElement.TYPE_NAME, "Method", null);
            MbElement ThridParent = Root.createElementAsFirstChild(MbElement.TYPE_NAME, "ThridParent", null);
            fieldsParent.addAfter(ThridParent);
            // TYPE fields
//              fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TYPE_NAME", MbElement.TYPE_NAME);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TYPE_NAME_VALUE", MbElement.TYPE_NAME_VALUE);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TYPE_UNKNOWN", MbElement.TYPE_UNKNOWN);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TYPE_VALUE", MbElement.TYPE_VALUE);
//
//           // VALIDATE fields
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALIDATE_COMPLETE", MbElement.VALIDATE_COMPLETE);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALIDATE_CONTENT", MbElement.VALIDATE_CONTENT);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALIDATE_CONTENT_AND_VALUE", MbElement.VALIDATE_CONTENT_AND_VALUE);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALIDATE_DEFERRED", MbElement.VALIDATE_DEFERRED);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALIDATE_EXCEPTION", MbElement.VALIDATE_EXCEPTION);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALIDATE_EXCEPTIONLIST", MbElement.VALIDATE_EXCEPTIONLIST);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALIDATE_IMMEDIATE", MbElement.VALIDATE_IMMEDIATE);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALIDATE_LOCAL_ERROR", MbElement.VALIDATE_LOCAL_ERROR);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALIDATE_NONE", MbElement.VALIDATE_NONE);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALIDATE_ROOT_BITSTREAM", MbElement.VALIDATE_ROOT_BITSTREAM);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALIDATE_USERTRACE", MbElement.VALIDATE_USERTRACE);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALIDATE_VALUE", MbElement.VALIDATE_VALUE);
//
//           // VALUE_STATE fields
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALUE_STATE_INVALID", MbElement.VALUE_STATE_INVALID);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALUE_STATE_UNDEFINED", MbElement.VALUE_STATE_UNDEFINED);
//           fieldsParent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "VALUE_STATE_VALID", MbElement.VALUE_STATE_VALID);

          
        // Instead of creating Method first and re-attaching
   
        
          
            // Final assembly
            outAssembly = new MbMessageAssembly(inAssembly, outMessage);

           
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(), null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}

	/**
	 * onPreSetupValidation() is called during the construction of the node
	 * to allow the node configuration to be validated.  Updating the node
	 * configuration or connecting to external resources should be avoided.
	 *
	 * @throws MbException
	 */
	@Override
	public void onPreSetupValidation() throws MbException {
	}

	/**
	 * onSetup() is called during the start of the message flow allowing
	 * configuration to be read/cached, and endpoints to be registered.
	 *
	 * Calling getPolicy() within this method to retrieve a policy links this
	 * node to the policy. If the policy is subsequently redeployed the message
	 * flow will be torn down and reinitialized to it's state prior to the policy
	 * redeploy.
	 *
	 * @throws MbException
	 */
	@Override
	public void onSetup() throws MbException {
	}

	/**
	 * onStart() is called as the message flow is started. The thread pool for
	 * the message flow is running when this method is invoked.
	 *
	 * @throws MbException
	 */
	@Override
	public void onStart() throws MbException {
	}

	/**
	 * onStop() is called as the message flow is stopped. 
	 *
	 * The onStop method is called twice as a message flow is stopped. Initially
	 * with a 'wait' value of false and subsequently with a 'wait' value of true.
	 * Blocking operations should be avoided during the initial call. All thread
	 * pools and external connections should be stopped by the completion of the
	 * second call.
	 *
	 * @throws MbException
	 */
	@Override
	public void onStop(boolean wait) throws MbException {
	}

	/**
	 * onTearDown() is called to allow any cached data to be released and any
	 * endpoints to be deregistered.
	 *
	 * @throws MbException
	 */
	@Override
	public void onTearDown() throws MbException {
	}

}
