import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbBLOB;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

public class Creating_a_new_message_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");
		MbMessage outMessage = new MbMessage();

		String myMsg = "The Message Data";
		MbElement outRoot = outMessage.getRootElement();
		MbElement outParser = outRoot.createElementAsLastChild(MbBLOB.PARSER_NAME);
		MbElement outBody = outParser.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BLOB", myMsg.getBytes());
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);

        // Propagate to output terminal
        out.propagate(outAssembly);
	}

	

}
