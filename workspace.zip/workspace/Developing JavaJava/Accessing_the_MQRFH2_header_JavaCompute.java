import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXPath;

public class Accessing_the_MQRFH2_header_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try {
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below
			addRfh2(outMessage);
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(), null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}

	public void addRfh2(MbMessage msg) throws MbException
	{
		MbElement root = msg.getRootElement();
		MbElement body = root.getLastChild();

		// insert new header before the message body
		MbElement rfh2 = body.createElementBefore("MQHRF2");

		rfh2.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "Version", new Integer(2));
		rfh2.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "Format", "MQSTR");
		rfh2.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "NameValueCCSID", new Integer(1208));

		MbElement psc = rfh2.createElementAsFirstChild(MbElement.TYPE_NAME, "psc", null);
		psc.createElementAsFirstChild(MbElement.TYPE_NAME, "Topic", "department");
		psc.createElementAsFirstChild(MbElement.TYPE_NAME, "QMgrName", "QM1");
		psc.createElementAsFirstChild(MbElement.TYPE_NAME, "QName", "PUBOUT");
		psc.createElementAsFirstChild(MbElement.TYPE_NAME, "RegOpt", "PersAsPub");

		MbXPath xp = new MbXPath("/MQMD/Format" + "[set-value(�MQHRF2�)]", root);
		root.evaluateXPath(xp);
	}

}
