import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbBLOB;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbJSON;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;

public class Large_input_messages_to_propagate_multiple_output_messages_JavaCompute extends MbJavaComputeNode {
   class Helper{
	   void add(MbElement parent,String name,Object value )throws MbException{
		   parent.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, name, value == null ? "" : String.valueOf(value));
	   }
   }
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");
		
		//Make a modifiable MbMessage based on the input message passed in on the inAssembly.
		MbMessage clonedInMessage=new MbMessage(inAssembly.getMessage());
		//Now partially parse the cloned input message one record at a time.
	    MbElement 	inputRootElement=clonedInMessage.getRootElement();
	    MbElement inputPropertiesElement = inputRootElement.getFirstElementByPath("Properties");
	    MbElement inputMQMDElement = inputRootElement.getFirstElementByPath("MQMD");
	    MbElement inputXMLNSCElement = inputRootElement.getFirstElementByPath("XMLNSC");

        MbElement inputXMLNSCRootTagElement = inputXMLNSCElement.getFirstChild(); //Move to the TestCase tag
        MbElement currentInputRecord = inputXMLNSCRootTagElement.getFirstChild(); //Move to the Record tag
	    
	    /*System.out.println("inAssembly"+inAssembly);
	    System.out.println("clonedInMessage"+clonedInMessage);
	    System.out.println("inputRootElement"+inputRootElement);
	    
	   /* MbMessage outMessage = new MbMessage(clonedInMessage);
	    MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);
	    out.propagate(outAssembly);*/
	    
	  /* MbMessage outMessage = new MbMessage();
		MbElement outRoot = outMessage.getRootElement();
		
		MbElement xmlnsc=outRoot.createElementAsLastChild("XMLNSC");
		MbElement outRootele =xmlnsc.createElementAsFirstChild(MbElement.TYPE_NAME,"outRootelement",null);
		Helper h = new Helper();
		h.add(outRootele, "inAssembly", inAssembly.toString());
	    h.add(outRootele, "clonedInMessage", clonedInMessage.toString());
	    h.add(outRootele, "inputRootElement", inputRootElement != null ? inputRootElement.toString() : "null");
	    h.add(outRootele, "inputPropertiesElement", inputPropertiesElement != null ? inputPropertiesElement.toString() : "null");
	    h.add(outRootele, "inputMQMDElement", inputMQMDElement != null ? inputMQMDElement.toString() : "null");
	    h.add(outRootele, "inputXMLNSCElement", inputXMLNSCElement != null ? inputXMLNSCElement.toString() : "null");
	    h.add(outRootele, "inputXMLNSCRootTagElement", inputXMLNSCRootTagElement != null ? inputXMLNSCRootTagElement.toString() : "null");
	    h.add(outRootele, "currentInputRecord", currentInputRecord != null ? currentInputRecord.toString() : "null");

	    // Propagate
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);
        // Propagate to output terminal
        out.propagate(outAssembly);*/
        while(currentInputRecord != null)
        {
          // Create a new output message for the record that we are going to be propagate.
          MbMessage outputMessage = new MbMessage();
          MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outputMessage);

          //Create new parsers folders in the output message.
          MbElement outputRootElement = outputMessage.getRootElement();
          MbElement outputPropertiesElement = outputRootElement.createElementAsLastChild(inputPropertiesElement.getParserClassName());
          MbElement outputMQMDElement = outputRootElement.createElementAsLastChild(inputMQMDElement.getParserClassName());
          MbElement outputXMLNSCElement = outputRootElement.createElementAsLastChild(inputXMLNSCElement.getParserClassName());       
          //Create the root tag in the output XMLNSC folder that will be used for this output record.
          MbElement outputXMLNSCRootTag = outputXMLNSCElement.createElementAsLastChild(MbElement.TYPE_NAME, "TestCase", null);
          //Create the record tag for this output message instance.
          MbElement currentOutputRecord = outputXMLNSCRootTag.createElementAsLastChild(MbElement.TYPE_NAME, "Record", null);

          //Copy the Properties Folder, MQMD header, and the current record.
          outputPropertiesElement.copyElementTree(inputPropertiesElement);
          outputMQMDElement.copyElementTree(inputMQMDElement);
          currentOutputRecord.copyElementTree(currentInputRecord);   

          //Propagate this message, requesting that the output message assembly be cleared after propagation.
          out.propagate(outAssembly, true);
          //Note: You do not need to call clearMessage on outputMessage because it was cleared after the propagation.

          //Take a reference to the current record so that it can be deleted.
          MbElement previousInputRecord = currentInputRecord;
          //Now move to the next input record ready for processing.
          currentInputRecord = currentInputRecord.getNextSibling();
          //Now that we have moved to the next sibling, delete the input record that has already been processed.
          previousInputRecord.delete();

        }
       
	    
	}
		

}
