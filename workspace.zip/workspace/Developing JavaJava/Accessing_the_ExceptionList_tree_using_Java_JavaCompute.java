import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class Accessing_the_ExceptionList_tree_using_Java_JavaCompute extends MbJavaComputeNode {

    public void evaluate(MbMessageAssembly inAssembly) throws MbException {

        MbOutputTerminal out = getOutputTerminal("out");
        MbOutputTerminal alt = getOutputTerminal("alternate");

        MbMessage inMessage = inAssembly.getMessage();
        MbMessageAssembly outAssembly = null;

        try {
            // Copy input message
            MbMessage outMessage = new MbMessage(inMessage);
            outAssembly = new MbMessageAssembly(inAssembly, outMessage);

            // ----------------------------------------------------------
            // User code: force an exception for demo
            if (true) {
                throw new Exception("Demo Exception: Something went wrong!");
            }
            // ----------------------------------------------------------

        } catch (Exception e) {
            // Exception will be caught here
            String text = (String) inAssembly.getExceptionList()
                    .evaluateXPath("string(//ParserException/Text)");

            if (text == null || text.isEmpty()) {
                text = e.toString();
            }

           
            // OR for debugging
            System.out.println("Exception caught: " + text);

            // Route to alternate terminal
            alt.propagate(outAssembly);
            return;
        }

        // Normal path
        out.propagate(outAssembly);
    }
}
